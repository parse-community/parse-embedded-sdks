#ifndef __SPI_FLASH_H__
#define __SPI_FLASH_H__
#include "common/include/nm_common.h"
#include "bus_wrapper/include/nm_bus_wrapper.h"
#include "driver/source/nmbus.h"
//#include "driver\source\nmdrv.h"
//#include "bsp\include\nm_bsp.h"
#include "spi_flash_map.h"

/**
	@fn		spi_flash_get_size
	
	@brief		
			Get size of SPI Flash.
	@return		
			The function shall return size of the SPI flash. 
*/
uint32 spi_flash_get_size(void);

/**
	@fn				spi_flash_read

	@brief			
					Read from data from SPI flash.
					
	@param[OUT]	pu8Buf
					Pointer to data buffer.

	@param[IN]		u32offset
					Address to read from at the SPI flash.

	@param[IN]		u32Sz
					Data size
	@return			
					The function shall return ZERO for successful operation and a negative value otherwise. 
*/ 
sint8 spi_flash_read(uint8 *pu8Buf, uint32 u32Addr, uint32 u32Sz);

/**
	@fn				spi_flash_write
	
	@brief			
					Proram SPI flash.
					
	@param[IN]		pu8Buf
					Pointer to data buffer.

	@param[IN]		u32Offset
					Address to write at the SPI flash

	@param[IN]		u32Sz
					Size to be written.
	@return			
					The function shall return ZERO for successful operation and a negative value otherwise. 

*/ 
sint8 spi_flash_write(uint8* pu8Buf, uint32 u32Offset, uint32 u32Sz);

/**

@fn			spi_flash_erase

@brief		
			Erase from data from SPI flash.

@note		
			Data size is limited by the SPI flash size only.
@return		
			The function shall return ZERO for successful operation and a negative value otherwise. 

*/
sint8 spi_flash_erase(uint32 u32Offset, uint32 u32Sz);

#endif	//__SPI_FLASH_H__
