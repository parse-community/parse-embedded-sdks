/*
* nm_bsp_samd21.h
*
*  Created on: oct 28, 2013
*      Author: MSM
*/

#ifndef _NM_BSP_SAMD21_H_
#define _NM_BSP_SAMD21_H_

#include "conf_winc.h"

#define NM_DEBUG		CONF_WIFI_M2M_DEBUG
#define NM_BSP_PRINTF	CONF_WIFI_M2M_PRINTF

#define USE_SPI         CONF_WIFI_M2M_SPI
#define EDGE_INTERRUPT  CONF_WIFI_M2M_EDGE_INTERRUPT
#endif /* _NM_BSP_SAMD21_H_ */
