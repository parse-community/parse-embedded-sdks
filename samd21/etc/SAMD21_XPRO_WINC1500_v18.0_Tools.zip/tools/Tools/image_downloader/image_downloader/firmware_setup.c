
#include "../efuse/efuse.h"
#include "firmware_setup.h"
#include "programmer.h"
#include "ota_hdr.h"


typedef struct {
	unsigned  MagicNumber;
	unsigned  SequnceNumber;
	unsigned  FirmwareVersion;
	unsigned char Builddate[sizeof(__DATE__)];
	unsigned char Buildtime[sizeof(__TIME__)];
}tstrInfoVector;

#define FIRMWARE_INFO_VECTOR_OFFSET		(3*4)
#define FLASH_INFO_VECTOR_OFFSET		(8+8)
#define INFO_VECTOR_MAGIC				0xdadbabba 
/*Firmware File Revison info*/
tstrM2mRev strfirmwareFileRev = {0};
tstrOtaControlSec  strOtaControlSec  = {0}; 

/*********************************************/
/* STATIC FUNCTIONS							 */
/*********************************************/

sint8 get_flash_firmware_version(tstrM2mRev *pstrCurentFirmware,tstrM2mRev *pstrOtaFirmware)
{
	sint8 ret = M2M_SUCCESS;
	tstrInfoVector strinfo = {0};
	ret = programmer_read((uint8*)&strOtaControlSec, M2M_CONTROL_FLASH_OFFSET, sizeof(tstrOtaControlSec));
	if(ret != M2M_SUCCESS)
	{
		M2M_PRINT("Failed to read spi flash\n");
		ret = M2M_ERR_FAIL;
		goto ERR;
	}
	if(strOtaControlSec.u32OtaMagicValue == OTA_MAGIC_VALUE)
	{
		if(pstrCurentFirmware != NULL)
		{
			pstrCurentFirmware->u8DriverMajor	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer >> 24);
			pstrCurentFirmware->u8DriverMinor	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer >> 20)&0x0f;
			pstrCurentFirmware->u8DriverPatch	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer >> 16)&0x0f;
			pstrCurentFirmware->u8FirmwareMajor	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer >> 8);
			pstrCurentFirmware->u8FirmwareMinor	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer >> 4)&0x0f;
			pstrCurentFirmware->u8FirmwarePatch	= (uint8)(strOtaControlSec.u32OtaCurrentworkingImagFirmwareVer&0x0f);
		}
		if(pstrOtaFirmware != NULL)
		{
			pstrOtaFirmware->u8DriverMajor		= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer >> 24);
			pstrOtaFirmware->u8DriverMinor		= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer >> 20)&0x0f;
			pstrOtaFirmware->u8DriverPatch		= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer >> 16)&0x0f;
			pstrOtaFirmware->u8FirmwareMajor	= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer >> 8);
			pstrOtaFirmware->u8FirmwareMinor	= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer >> 4)&0x0f;
			pstrOtaFirmware->u8FirmwarePatch	= (uint8)(strOtaControlSec.u32OtaRollbackImagFirmwareVer & 0x0f);
		}
	}
	else
	{
		ret = M2M_ERR_FAIL;
		//M2M_ERR("Invaild Control structure\n");
		goto ERR;
	}

	ret = programmer_read((uint8*)&strinfo, strOtaControlSec.u32OtaCurrentworkingImagOffset + M2M_PROGRAM_FLASH_SZ+ FLASH_INFO_VECTOR_OFFSET, sizeof(tstrInfoVector));
	if(strinfo.MagicNumber == INFO_VECTOR_MAGIC)
	{
		if(pstrCurentFirmware != NULL)
		{
			//pstrCurentFirmware->u8DriverMajor		= (uint8)(strinfo.FirmwareVersion >> 24);
			//pstrCurentFirmware->u8DriverMinor		= (uint8)(strinfo.FirmwareVersion >> 16);
			//pstrCurentFirmware->u8FirmwareMajor	= (uint8)(strinfo.FirmwareVersion >> 8);
			//pstrCurentFirmware->u8FirmwareMinor	= (uint8)(strinfo.FirmwareVersion);

			m2m_memcpy(pstrCurentFirmware->BuildDate,strinfo.Builddate,sizeof(__DATE__));
			m2m_memcpy(pstrCurentFirmware->BuildTime,strinfo.Buildtime,sizeof(__TIME__));
		}
	}

	ret = programmer_read((uint8*)&strinfo, strOtaControlSec.u32OtaRollbackImageOffset + M2M_PROGRAM_FLASH_SZ + FLASH_INFO_VECTOR_OFFSET, sizeof(tstrInfoVector));
	if(strinfo.MagicNumber == INFO_VECTOR_MAGIC)
	{
		if(pstrCurentFirmware != NULL)
		{
			//pstrOtaFirmware->u8DriverMajor	= (uint8)(strinfo.FirmwareVersion >> 24);
			//pstrOtaFirmware->u8DriverMinor	= (uint8)(strinfo.FirmwareVersion >> 16);
			//pstrOtaFirmware->u8FirmwareMajor	= (uint8)(strinfo.FirmwareVersion >> 8);
			//pstrOtaFirmware->u8FirmwareMinor	= (uint8)(strinfo.FirmwareVersion);

			m2m_memcpy(pstrOtaFirmware->BuildDate,strinfo.Builddate,sizeof(__DATE__));
			m2m_memcpy(pstrOtaFirmware->BuildTime,strinfo.Buildtime,sizeof(__TIME__));
		}
	}
ERR:
	return ret;
}


sint8 get_firmwarefile_version(char * file, tstrM2mRev *pstrm2mrev)
{
	FILE *fp;
	sint8 ret = M2M_SUCCESS;
	uint32 sz = 0;
	fp = fopen(file, "rb");

	if(fp)
	{
		fseek(fp, 0L, SEEK_END);
		sz = ftell(fp);
		fseek(fp, FIRMWARE_INFO_VECTOR_OFFSET, SEEK_SET);
		if(sz > sizeof(tstrInfoVector))
		{
			tstrInfoVector strinfo;
			fread(&strinfo,1,sizeof(tstrInfoVector),fp);
			if(strinfo.MagicNumber == INFO_VECTOR_MAGIC)
			{
				strfirmwareFileRev.u8DriverMajor		= (uint8)(strinfo.FirmwareVersion >> 24);
				strfirmwareFileRev.u8DriverMinor		= (uint8)(strinfo.FirmwareVersion >> 20)&0x0f;
				strfirmwareFileRev.u8DriverPatch		= (uint8)(strinfo.FirmwareVersion >> 16)&0x0f;
				strfirmwareFileRev.u8FirmwareMajor	= (uint8)(strinfo.FirmwareVersion >> 8);
				strfirmwareFileRev.u8FirmwareMinor	= (uint8)(strinfo.FirmwareVersion >> 4)&0x0f;
				strfirmwareFileRev.u8FirmwarePatch	= (uint8)(strinfo.FirmwareVersion & 0x0f);

				m2m_memcpy(strfirmwareFileRev.BuildDate,strinfo.Builddate,sizeof(__DATE__));
				m2m_memcpy(strfirmwareFileRev.BuildTime,strinfo.Buildtime,sizeof(__TIME__));
				if(pstrm2mrev != NULL)
				{
					m2m_memcpy((uint8*)pstrm2mrev,(uint8*)&strfirmwareFileRev,sizeof(tstrM2mRev));
				}
			
				M2M_DBG("Firmware ver   : %u.%u.%u\n", strfirmwareFileRev.u8FirmwareMajor, strfirmwareFileRev.u8FirmwareMinor,strfirmwareFileRev.u8FirmwarePatch);
				M2M_DBG("Min driver ver : %u.%u.%u\n", strfirmwareFileRev.u8DriverMajor,strfirmwareFileRev.u8DriverMinor,strfirmwareFileRev.u8DriverPatch);
				M2M_DBG("Firmware Build %s Time %s\n",strfirmwareFileRev.BuildDate,strfirmwareFileRev.BuildTime);
			}
			else
			{
				ret = M2M_ERR_FAIL;
				NM_BSP_PRINTF("File is not eligable for firmware version number <17.2 \n%s\n",file);
			}
		}
		else
		{
			ret = M2M_ERR_FAIL;
			NM_BSP_PRINTF("Incorrect file size \n%s\n",file);
		}
		fclose(fp);
	}
	else
	{
		ret = M2M_ERR_FAIL;
		NM_BSP_PRINTF("failed to open firmware file \n%s\n",file);
	}

	return ret;

}