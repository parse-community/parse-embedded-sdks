/**
*  @file		main.c				
*  @brief		This module contains M2M driver test application
*  @author		M. Abdelmawla
*  @date		10 JULY 2012
*  @version		1.0	
*/
#include "./image_downloader/firmware_setup.h"
/**
* CMD MACROS 
*/

/**
* COMMAND LINE ARGUMENTS BITS IN RETURN BYTE 
*/
#define NO_WAIT_BIT			(0x02)	/*!< Positiion of no_wait bit in the byte. */
#define ARGS_ERR_BIT		(0x40)	/*!< Positiion of arguments_error bit in the byte. */
/**
* SET VALUES DEPEND ON COMMAND LINE ARGUMENTS 
*/
#define SET_NO_WAITE_BIT(x) (x |= NO_WAIT_BIT)	/*!< set no_wait bit in the byte to 1. */
#define SET_ARGS_ERR_BIT(x)	(x |= ARGS_ERR_BIT)	/*!< set arguments_error bit in the byte to 1. */
/** 
* CHECK FOR VALUES FOR EACH CMD IN COMMAND LINE ARGUMENTS 
*/
#define NO_WAIT(x)			(x & NO_WAIT_BIT)	/*!< It will return 1 if no_wait argument had been passed to main */
#define ARGS_ERR(x)			(x & ARGS_ERR_BIT)	/*!< It will return 1 if invalid argument had been passed to main */


/**
*	@fn		print_nmi
*	@brief	print owener info.
*	@return	void
*	@author	
*	@date	
*	@version	1.0
*/ 
static void print_nmi(void)
{
	M2M_PRINT("********************************************\n\r");
	M2M_PRINT("*  >Programmer for WINC1500 SPI Flash<     *\n\r");
	M2M_PRINT("*      Owner:  Atmel Corporation           *\n\r");
	M2M_PRINT("********************************************\n\r");
}

char image_path[255] = M2M_AIO_FILE;

/**
*	@fn			checkArguments
*	@brief		Check for argument passed by user to main function
*	@param[IN]	char * argv[]
*					Argument vector from main
*	@param[IN]	uint8 argc
*					Arguments count
*	@note		If new argument will be added, you MUST modify this function
*	@author	
*	@version	1.0
*/ 
static uint8 checkArguments(char * argv[],uint8 argc, uint8* portNum)
{
	sint8 ret = M2M_SUCCESS;
	uint8 loopCntr = 1;

	*portNum = 0;
	if(1 >= argc) goto ERR;
	for(;loopCntr<argc;loopCntr++)
	{
		if(strstr(argv[loopCntr],"-fw_path"))
		{
			if(argc-loopCntr > 1) {
				memcpy(image_path, argv[loopCntr+1], strlen(argv[loopCntr+1]));
			}
			continue;
		}
		if(strstr(argv[loopCntr],"-no_wait"))
		{
			SET_NO_WAITE_BIT(ret);
			continue;
		}
		if(strstr(argv[loopCntr],"-port"))
		{
			if(argc-loopCntr > 1)
			{
				*portNum = atoi(argv[++loopCntr]);
			}
			continue;
		}
	}
ERR:
	return ret;
}

sint8 burn_image(void)
{
	sint8	ret = M2M_SUCCESS;
	FILE	*pf = NULL;
	uint8	u8ImageData[FLASH_TOTAL_SZ]={0};
	uint32	u32ImageSz = 0;
		
	if(!memcmp(M2M_AIO_FILE, image_path, strlen(M2M_AIO_FILE))) {
		M2M_PRINT("\n(WARN)Default PATH for image file will be used.\r\n");
	}

	pf = fopen(image_path,"r+");
	
	M2M_PRINT("\n");
	if(NULL == pf) {
		M2M_PRINT("[ERR]Unable to open Firmware file:\n\t\"%s\"\r\n",image_path);
		ret = M2M_ERR_FAIL;
		goto _END;
	}

	M2M_PRINT("Firmware image file has been opened:\n\t\"%s\"\r\n",image_path);
	
	fseek(pf, 0L, SEEK_END);
	u32ImageSz = ftell(pf);
	fseek(pf, 0L, SEEK_SET);
	
	if(u32ImageSz > FLASH_TOTAL_SZ) {
		M2M_PRINT("[ERR]Image's size is larger than Flash size.\r\n");
		ret = M2M_ERR_FAIL;
		goto _END;
	}
	
	fread(u8ImageData, u32ImageSz, 1, pf);
	fclose(pf);

	if(M2M_SUCCESS != programmer_erase_firmware_image()) {
		M2M_PRINT("Error while erasing SPI FLash.\r\n");
		ret = M2M_ERR_FAIL;
		goto _END;
	}
	
	if(M2M_SUCCESS != programmer_write_firmware_image(u8ImageData, 0, u32ImageSz)) {
		M2M_PRINT(">\r\n[ERR]Error Writing Image\r\n");
		ret = M2M_ERR_FAIL;
		goto _END;
	}
	
_END:
	return ret;
}

int main(int argc, char* argv[])
{
	sint8 ret = M2M_SUCCESS;
	tstrM2mRev strFirmFileInfo;
	tstrM2mRev strCurrentFirmInfo;
	tstrM2mRev strOtaFirmInfo;
	uint8 commands_val = 0;
	nm_bsp_init();
	print_nmi();
	commands_val = checkArguments(argv,argc,&ret);
	if(ARGS_ERR(commands_val)) 
	{
		M2M_ERR("\n>>Invalid arguments\n");
		goto END;
	}
	
	M2M_PRINT(">>Init Programmer\n");
	ret = programmer_init(&ret);
	if(ret != M2M_SUCCESS)
	{
		M2M_PRINT("(ERR)Failed To intilize programmer\n");
		goto END;
	}
	ret = get_firmwarefile_version(M2M_FIRMWARE_FILE,&strFirmFileInfo);
	if(ret == M2M_SUCCESS)
	{
		M2M_PRINT("----- Input Firmware File Version-----\n");
		M2M_PRINT("Firmware ver   : %u.%u.%u\n", strFirmFileInfo.u8FirmwareMajor, strFirmFileInfo.u8FirmwareMinor,strFirmFileInfo.u8FirmwarePatch);
		M2M_PRINT("Min driver ver : %u.%u.%u\n", strFirmFileInfo.u8DriverMajor,strFirmFileInfo.u8DriverMinor,strFirmFileInfo.u8DriverPatch);
		M2M_PRINT("Firmware Build %s Time %s\n",strFirmFileInfo.BuildDate,strFirmFileInfo.BuildTime);
	}
	ret = get_flash_firmware_version(&strCurrentFirmInfo,&strOtaFirmInfo);
	if(ret == M2M_SUCCESS)
	{
		if((strCurrentFirmInfo.u8FirmwareMajor != 0)||(strCurrentFirmInfo.u8FirmwareMinor != 0))
		{
			M2M_PRINT("----- Flash Curren working Firmware Image Version-----\n");
			M2M_PRINT("Firmware ver   : %u.%u.%u\n", strCurrentFirmInfo.u8FirmwareMajor, strCurrentFirmInfo.u8FirmwareMinor,strCurrentFirmInfo.u8FirmwarePatch);
			M2M_PRINT("Min driver ver : %u.%u.%u\n", strCurrentFirmInfo.u8DriverMajor,strCurrentFirmInfo.u8DriverMinor,strCurrentFirmInfo.u8DriverPatch);
			M2M_PRINT("Firmware Build %s Time %s\n",strCurrentFirmInfo.BuildDate,strCurrentFirmInfo.BuildTime);
		}
		
		if((strOtaFirmInfo.u8FirmwareMajor != 0)||(strOtaFirmInfo.u8FirmwareMinor != 0))
		{
			M2M_PRINT("----- Flash Ota Rollback Firmware Image Version-----\n");
			M2M_PRINT("Firmware ver   : %u.%u.%u\n", strOtaFirmInfo.u8FirmwareMajor, strOtaFirmInfo.u8FirmwareMinor,strOtaFirmInfo.u8FirmwarePatch);
			M2M_PRINT("Min driver ver : %u.%u.%u\n", strOtaFirmInfo.u8DriverMajor,strOtaFirmInfo.u8DriverMinor,strOtaFirmInfo.u8DriverPatch);
			M2M_PRINT("Firmware Build %s Time %s\n",strOtaFirmInfo.BuildDate,strOtaFirmInfo.BuildTime);
		}
	}
#ifdef PROFILING
	{
	uint32 u32T1=GetTickCount();
#endif
	ret = burn_image();
	if(M2M_SUCCESS == ret) {
		M2M_PRINT("\nImage downloaded successfully.\r\n");
	}

	programmer_deinit();
#ifdef PROFILING
	M2M_PRINT("\n>>This task finished after %5.2f sec\n\r",(GetTickCount() - u32T1)/1000.0);
	}
#endif
END:
	if(!NO_WAIT(commands_val))
		system("pause");
	return ret;	
}
